﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        lbl_result = New Label()
        btn_add = New Button()
        btn_sub = New Button()
        btn_multi = New Button()
        btn_div = New Button()
        txt_num1 = New TextBox()
        txt_num2 = New TextBox()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 20.0F, FontStyle.Bold Or FontStyle.Underline, GraphicsUnit.Point)
        Label1.Location = New Point(242, 9)
        Label1.Name = "Label1"
        Label1.Size = New Size(371, 37)
        Label1.TabIndex = 0
        Label1.Text = "CALCULATOR APPLICATION"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(167, 81)
        Label2.Name = "Label2"
        Label2.Size = New Size(192, 21)
        Label2.TabIndex = 1
        Label2.Text = "Enter Your First Number"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.Location = New Point(167, 115)
        Label3.Name = "Label3"
        Label3.Size = New Size(216, 21)
        Label3.TabIndex = 2
        Label3.Text = "Enter Your Second Number"
        ' 
        ' lbl_result
        ' 
        lbl_result.AutoSize = True
        lbl_result.Font = New Font("Segoe UI", 20.0F, FontStyle.Bold, GraphicsUnit.Point)
        lbl_result.Location = New Point(167, 267)
        lbl_result.Name = "lbl_result"
        lbl_result.Size = New Size(119, 37)
        lbl_result.TabIndex = 3
        lbl_result.Text = "RESULT:"
        ' 
        ' btn_add
        ' 
        btn_add.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        btn_add.Location = New Point(167, 176)
        btn_add.Name = "btn_add"
        btn_add.Size = New Size(99, 34)
        btn_add.TabIndex = 4
        btn_add.Text = "ADDITION"
        btn_add.UseVisualStyleBackColor = True
        ' 
        ' btn_sub
        ' 
        btn_sub.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        btn_sub.Location = New Point(272, 176)
        btn_sub.Name = "btn_sub"
        btn_sub.Size = New Size(131, 34)
        btn_sub.TabIndex = 5
        btn_sub.Text = "SUBTRACTION"
        btn_sub.UseVisualStyleBackColor = True
        ' 
        ' btn_multi
        ' 
        btn_multi.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        btn_multi.Location = New Point(409, 176)
        btn_multi.Name = "btn_multi"
        btn_multi.Size = New Size(150, 34)
        btn_multi.TabIndex = 6
        btn_multi.Text = "MULTIPLICATION"
        btn_multi.UseVisualStyleBackColor = True
        ' 
        ' btn_div
        ' 
        btn_div.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        btn_div.Location = New Point(565, 176)
        btn_div.Name = "btn_div"
        btn_div.Size = New Size(92, 34)
        btn_div.TabIndex = 7
        btn_div.Text = "DIVISION"
        btn_div.UseVisualStyleBackColor = True
        ' 
        ' txt_num1
        ' 
        txt_num1.Location = New Point(408, 71)
        txt_num1.Multiline = True
        txt_num1.Name = "txt_num1"
        txt_num1.Size = New Size(249, 31)
        txt_num1.TabIndex = 8
        ' 
        ' txt_num2
        ' 
        txt_num2.Location = New Point(408, 117)
        txt_num2.Multiline = True
        txt_num2.Name = "txt_num2"
        txt_num2.Size = New Size(249, 33)
        txt_num2.TabIndex = 9
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7.0F, 15.0F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(txt_num2)
        Controls.Add(txt_num1)
        Controls.Add(btn_div)
        Controls.Add(btn_multi)
        Controls.Add(btn_sub)
        Controls.Add(btn_add)
        Controls.Add(lbl_result)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lbl_result As Label
    Friend WithEvents btn_add As Button
    Friend WithEvents btn_sub As Button
    Friend WithEvents btn_multi As Button
    Friend WithEvents btn_div As Button
    Friend WithEvents txt_num1 As TextBox
    Friend WithEvents txt_num2 As TextBox
End Class
