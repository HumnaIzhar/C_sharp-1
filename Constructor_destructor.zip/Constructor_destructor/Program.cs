﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_destructor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            Console.WriteLine("*****************");
            Employee emp1 = new Employee(500);
            Console.WriteLine("*****************");
            Employee emp2 = new Employee("Pakistan");
            //Console.ReadKey();
            Console.WriteLine("STUDENT DETAILS");
            Student std = new Student();
            Student std_details =new Student("*******Student Batch Details**********");
        }
    }
}
