﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_destructor
{
    internal class Employee
    {
        public int id;
        public string name;
        public int age;

        // Constructors
        public Employee()
        {
           id = 123;
           name = "Ali";
           age = 21;
            Console.WriteLine("The id is:"+id);
            Console.WriteLine("The name is:" + name);
            Console.WriteLine("The age is:" + age);

        }
        public Employee(int a)
        {
            Console.WriteLine("Your value is:"+a);
        }
        public Employee(string b) 
        {
            Console.WriteLine("Your country is:" + b);
        }

        //Destructor:Space free or memory free.
        ~Employee()
        {
            Console.WriteLine("Destructor");
        }
    }
    internal class Student
    {
        //Construtors
        public Student()
        {
            Console.WriteLine("Enter your id");
            int std_id =int.Parse(Console.ReadLine());
            Console.WriteLine("Your student id is:"+std_id);

            Console.WriteLine("Enter your name");
            string std_name = Console.ReadLine();
            Console.WriteLine("Your name is:"+std_name);
        }
        public Student(string heading)
        {
            Console.WriteLine(heading);
            Console.WriteLine("Enter Your semster");
            string sem = Console.ReadLine();
            Console.WriteLine("Your semster is:" + sem);

            Console.WriteLine("Enter Your batch");
            string batch = Console.ReadLine();
            Console.WriteLine("Your Batch is:" + batch);
        }
        //Destructor
        ~Student()
        {
            Console.WriteLine("Student Detructor");
            
        }
    }
}
