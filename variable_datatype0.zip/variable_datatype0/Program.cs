﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
//Console.WriteLine("Hello, GoodWorld!");

//string stdname = "huma";
//Console.WriteLine("student name is :" + stdname);

//int stdage = 23;
//Console.WriteLine("student age is :" + stdage);

//double stdper = 95.5;
//Console.WriteLine("student percentage is :" + stdper);

//bool stdexsist = true;
//Console.WriteLine("student is exsist or not :" + stdexsist);

//Console.WriteLine("enter your name:");
//string name = Console.ReadLine();
//Console.WriteLine("your name is :" + name);

Console.WriteLine("enter your phone number :");
int phone = int.Parse(Console.ReadLine());
Console.WriteLine("your phone number is :" + phone);
