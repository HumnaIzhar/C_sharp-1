﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_and_Interface_Classes
{
    //interface:an interface is like an abstract base class with only abstract members.
    //A class or struct that implements the interface must implement all its members.
    internal class Data
    {
    }
    public interface Inter1
    {
        //Declare Method
        int sum(int x,int y);

        int div(int x ,int y);
    }
    public class Inter2:Inter1
    {
        //Implenting Method
        public int div(int x,int y)
        {
            Console.WriteLine("Division is:" + (x/y));
            return (x/y);
        }
        public int  sum(int x,int y)
        {
            Console.WriteLine("Addition is:"+(x+y));
            return (x+y);
        }
    }
}
