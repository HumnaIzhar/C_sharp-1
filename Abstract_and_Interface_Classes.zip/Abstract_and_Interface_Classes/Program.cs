﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_and_Interface_Classes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            XYZ obj = new XYZ();
            obj.sum(100, 40);
            obj.sub(100, 50);

            Inter2 inter = new Inter2();
            inter.div(100, 20);
            inter.sum(100, 30);
            Console.ReadKey();
        }
    }
    //Abstract: a restricted class that cannot be used to create objects
    //(to access it, it must be inherited from another class). Abstract method: can only be used in an abstract
    //class,and it does not have a body. The body is provided by the derived class (inherited from).
    //and in define method always use the override keyword. 
    public abstract class ABC
    {
        //Method Declaration 
        //non Abstract Method
        public int sum(int x,int y)
        {
            //Method define
            Console.WriteLine("Addition is:"+(x+y));
            return (x+y);   
        }
        //Abstract method Declaration
        public abstract int sub(int x,int y);

    }
    public class XYZ:ABC
    {
        public override int sub(int x,int y)
        {
            Console.WriteLine("subtraction is:"+(x-y));
            return (x-y);
        }
    }
}
