﻿using System.Diagnostics;

namespace classess_objects
{
    [DebuggerDisplay("{GetDebuggerDisplay(),nq}")]
    internal class Class_HouseBase2
    {
    }
}