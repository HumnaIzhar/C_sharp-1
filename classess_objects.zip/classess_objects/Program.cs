﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classess_objects
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //object
            Myclass myobj = new Myclass();
            Console.WriteLine("***********Student_Data***********");
            myobj.show();
            Console.WriteLine("***********Student_Personal_Record************");
            myobj.stdrecord();
            Console.WriteLine("**************Employee_Details************");
            myobj.Office();
            //Console.WriteLine("***********Resturant_Labour_Details***********");
            //myobj.resturant();
            Console.WriteLine("************House_Details************");
            Class_House house = new Class_House();
            house.House();
            Console.WriteLine("***********Resturant_Labour_Details***********");
            house.resturant();
            

            Console.ReadKey();
        }
    }
    //creating a class
    class Myclass
    {
        //prperties
        public int stdid;
        public string stdname;
        public int stdclass;
        public string stdemail;


        //method
        public void show()
        {
            //initialize
            stdid = 111;
            stdname = "ali";
            stdclass = 7;
            stdemail = "ali@gmail.com";

            Console.WriteLine("Your id is:" + stdid);
            Console.WriteLine("Your name is:" + stdname);
            Console.WriteLine("Your class is:" + stdclass);
            Console.WriteLine("Your email is:" + stdemail);
            
        }
        public string stdphoneno;
        public string stdcity;
        public string stdsection;
        public void stdrecord()
        {
            stdphoneno = "123456789";
            stdcity = "karachi";
            stdsection = "A";
            Console.WriteLine("student phone no:" + stdphoneno);
            Console.WriteLine("student city is:" + stdcity);
            Console.WriteLine("student section is:" + stdsection);

        }
        public string office_name;
        public int employees;
        public int departments;
        public string area;

        public void Office()
        {
            office_name = "Lucky Cement";
            employees = 200;
            departments = 10;
            area = "Pechs";

            Console.WriteLine("Office name is:" + office_name);
            Console.WriteLine("Office Employees:" + employees);
            Console.WriteLine("Office departments:" + departments);
            Console.WriteLine("Office Area:" + area);
            

        }
        //public string house_location;
        //public string house_name;
        //public int house_yards;
        //public int house_floors;

        //public void House()
        //{
        //    //initialize
        //    house_location = "Main";
        //    house_name = "Saads House";
        //    house_yards = 400;
        //    house_floors = 3;

        //    Console.WriteLine("House Location:" + house_location);
        //    Console.WriteLine("House name:" + house_name);
        //    Console.WriteLine("House yards:" + house_yards);
        //    Console.WriteLine("House Floors:" + house_floors);


        //}
        //public int waiter_id;
        //public string waiter_name;
        //public int salary;

        //public void resturant()
        //{
        //    waiter_id = 123;
        //    waiter_name = "Affan";
        //    salary = 50000;

        //    Console.WriteLine("waiter id is:" + waiter_id);
        //    Console.WriteLine("waiter Name is:" + waiter_name);
        //    Console.WriteLine("waiter Salary is:" + salary);
        //}

    }
}
