﻿namespace classess_objects
{
    internal class Class_HouseBase
    {
    }
}