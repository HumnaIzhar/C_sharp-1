﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classess_objects
{
    internal class Class_House
    {
        public string house_location;
        public string house_name;
        public int house_yards;
        public int house_floors;

        public void House()
        {
            //initialize
            house_location = "Main";
            house_name = "Saads House";
            house_yards = 400;
            house_floors = 3;

            Console.WriteLine("House Location:" + house_location);
            Console.WriteLine("House name:" + house_name);
            Console.WriteLine("House yards:" + house_yards);
            Console.WriteLine("House Floors:" + house_floors);
            

        }
        public int waiter_id;
        public string waiter_name;
        public int salary;

        public void resturant()
        {
            waiter_id = 123;
            waiter_name = "Affan";
            salary = 50000;

            Console.WriteLine("waiter id is:" + waiter_id);
            Console.WriteLine("waiter Name is:" + waiter_name);
            Console.WriteLine("waiter Salary is:" + salary);
        }


    }
}
