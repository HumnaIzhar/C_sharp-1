namespace Range_calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void show_table_Click(object sender, EventArgs e)
        {
            int number = int.Parse(txt_number.Text);
            int range = int.Parse(txt_range.Text);
            for (int i = 1; i <= range; i++)
            {
                list_table.Items.Add(number + "*" + i + "=" + number * i);
            }
            txt_number.Text = "";
            txt_range.Text = ""; 

        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            list_table.Items.Clear();
        }
    }
}