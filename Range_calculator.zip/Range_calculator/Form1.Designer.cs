﻿namespace Range_calculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            list_table = new ListBox();
            txt_number = new TextBox();
            txt_range = new TextBox();
            show_table = new Button();
            btn_clear = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(40, 32);
            label1.Name = "label1";
            label1.Size = new Size(145, 28);
            label1.TabIndex = 0;
            label1.Text = "Enter Number";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(40, 134);
            label2.Name = "label2";
            label2.Size = new Size(71, 28);
            label2.TabIndex = 1;
            label2.Text = "Range";
            // 
            // list_table
            // 
            list_table.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            list_table.ForeColor = Color.FromArgb(64, 0, 0);
            list_table.FormattingEnabled = true;
            list_table.ItemHeight = 21;
            list_table.Location = new Point(493, 32);
            list_table.Name = "list_table";
            list_table.Size = new Size(249, 256);
            list_table.TabIndex = 2;
            // 
            // txt_number
            // 
            txt_number.Location = new Point(40, 76);
            txt_number.Multiline = true;
            txt_number.Name = "txt_number";
            txt_number.Size = new Size(188, 35);
            txt_number.TabIndex = 3;
            // 
            // txt_range
            // 
            txt_range.Location = new Point(40, 194);
            txt_range.Multiline = true;
            txt_range.Name = "txt_range";
            txt_range.Size = new Size(188, 33);
            txt_range.TabIndex = 4;
            txt_range.TextChanged += textBox2_TextChanged;
            // 
            // show_table
            // 
            show_table.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            show_table.Location = new Point(40, 271);
            show_table.Name = "show_table";
            show_table.Size = new Size(102, 35);
            show_table.TabIndex = 5;
            show_table.Text = "Show Table";
            show_table.UseVisualStyleBackColor = true;
            show_table.Click += show_table_Click;
            // 
            // btn_clear
            // 
            btn_clear.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btn_clear.Location = new Point(165, 271);
            btn_clear.Name = "btn_clear";
            btn_clear.Size = new Size(105, 35);
            btn_clear.TabIndex = 6;
            btn_clear.Text = "Clear";
            btn_clear.UseVisualStyleBackColor = true;
            btn_clear.Click += btn_clear_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btn_clear);
            Controls.Add(show_table);
            Controls.Add(txt_range);
            Controls.Add(txt_number);
            Controls.Add(list_table);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private ListBox list_table;
        private TextBox txt_number;
        private TextBox txt_range;
        private Button show_table;
        private Button btn_clear;
    }
}