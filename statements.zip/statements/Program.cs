﻿// See https://aka.ms/new-console-template for more information

//If Statement
//int num = -4;
//if(num<0)
//{
//    Console.WriteLine("The number is negative");
//}

//If Else
//int num = 10;
//if(num<0)
//{
//    Console.WriteLine("The number is negative");

//}
//else
//{
//    Console.WriteLine("The number is positive");

//}

//If Else If
//int num = 13;
//if (num <= 0)
//{
//    Console.WriteLine("The number is negative");

//}
//else if ((num % 2) == 0)
//{
//    Console.WriteLine("The number is even");

//}
//else
//{
//    Console.WriteLine("Not Found");
//}

//Nested If
int yrsofservice = 3;
double salary = 1500;
int bonus = 0;
if (yrsofservice < 5)
{
    if (salary < 500)
    {
        bonus = 100;
    }
    else
    {
        bonus = 200;
    }
}
else
{
    bonus = 700;
}
Console.WriteLine("Bonus amount :" + bonus);

//Switch Case
//int day = 5;
//switch (day) { 
//        case 1:
//        Console.WriteLine("Sunday");
//        break;
//        case 2:
//        Console.WriteLine("Monday");
//        break;
//        case 3:
//        Console.WriteLine("Tuesday");
//        break;
//        case 4:
//        Console.WriteLine("Wednesday");
//        break;
//        case 5:
//        Console.WriteLine("Thursday");
//        break;
//        case 6:
//        Console.WriteLine("Friday");
//        break;
//        case 7:
//        Console.WriteLine("Saturday");
//        break;
//    default:
//        Console.WriteLine("Enter number between 1 to 7");
//        break;

//}