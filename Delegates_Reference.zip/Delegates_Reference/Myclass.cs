﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates_Reference
{
    delegate void show_reference();
    internal class Myclass
    {
        public void show()
        {
            Console.WriteLine("This method is called through delegate reference");
        }
    }
}
