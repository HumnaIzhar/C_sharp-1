﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates_Reference
{
    //non-parametic
    delegate void mydelegate();

    //parametic
    delegate void mydelegate2(int a);

    //lemda expression
    delegate void mydelegate3(string name);
    internal class Employee
    {
       
    }
}
