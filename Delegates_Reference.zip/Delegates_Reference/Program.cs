﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates_Reference
{
    internal class Program
    {

        static void Main(string[] args)
        {
            Myclass mycl = new Myclass();
            mycl.show();
            show_reference sr = new show_reference(mycl.show);
            sr.Invoke();
            Console.WriteLine("******************");

            //Non parametic delegate
            mydelegate md1 = delegate ()
            {
                Console.WriteLine("This is anonymous Method ");
            };
            md1.Invoke();

            //Parametic delegate
            Console.WriteLine("******************");
            mydelegate2 md2 = delegate (int num)
            {
                Console.WriteLine(num);
            };
            md2.Invoke(500);

            //Lemda expression
            Console.WriteLine("**************");
            mydelegate3 md3 = (string name) =>
            {
                Console.WriteLine(name);
            };
            md3.Invoke("Aptech learning");

            //NumberChanger nc1 = new NumberChanger(sum);
            //NumberChanger nc2 = new NumberChanger(subtract);

            Console.ReadLine();
        }
    }
}
