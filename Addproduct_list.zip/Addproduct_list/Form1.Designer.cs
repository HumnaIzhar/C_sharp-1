﻿namespace Addproduct_list
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            product_list = new ListBox();
            label2 = new Label();
            txt_product = new TextBox();
            btn_add = new Button();
            btn_clear = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(78, 41);
            label1.Name = "label1";
            label1.Size = new Size(204, 28);
            label1.TabIndex = 0;
            label1.Text = "Enter Product Name";
            // 
            // product_list
            // 
            product_list.FormattingEnabled = true;
            product_list.ItemHeight = 15;
            product_list.Location = new Point(493, 110);
            product_list.Name = "product_list";
            product_list.Size = new Size(238, 229);
            product_list.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(493, 41);
            label2.Name = "label2";
            label2.Size = new Size(150, 28);
            label2.TabIndex = 2;
            label2.Text = "Product_Name";
            // 
            // txt_product
            // 
            txt_product.Location = new Point(78, 101);
            txt_product.Multiline = true;
            txt_product.Name = "txt_product";
            txt_product.Size = new Size(204, 34);
            txt_product.TabIndex = 3;
            // 
            // btn_add
            // 
            btn_add.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btn_add.Location = new Point(78, 188);
            btn_add.Name = "btn_add";
            btn_add.Size = new Size(124, 33);
            btn_add.TabIndex = 4;
            btn_add.Text = "Add Product";
            btn_add.UseVisualStyleBackColor = true;
            btn_add.Click += btn_add_Click;
            // 
            // btn_clear
            // 
            btn_clear.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btn_clear.Location = new Point(78, 262);
            btn_clear.Name = "btn_clear";
            btn_clear.Size = new Size(124, 33);
            btn_clear.TabIndex = 5;
            btn_clear.Text = "Clear";
            btn_clear.UseVisualStyleBackColor = true;
            btn_clear.Click += btn_clear_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(810, 450);
            Controls.Add(btn_clear);
            Controls.Add(btn_add);
            Controls.Add(txt_product);
            Controls.Add(label2);
            Controls.Add(product_list);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ListBox product_list;
        private Label label2;
        private TextBox txt_product;
        private Button btn_add;
        private Button button2;
        private Button btn_clear;
    }
}