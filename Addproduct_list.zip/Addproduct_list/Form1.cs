namespace Addproduct_list
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            string product_name = txt_product.Text;
            product_list.Items.Add(product_name);
            txt_product.Text = "";
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            product_list.Items.Clear();
        }
    }
}