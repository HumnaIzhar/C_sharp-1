﻿// See https://aka.ms/new-console-template for more information

using System.ComponentModel;
//while LOOP
//int num = 1;
//Console.WriteLine("Even numbers");
//while (num <= 11)
//{
//    if ((num % 2) == 0)
//    {
//        Console.WriteLine(num);
//    }
//    num = num + 1;
//}

//Nested While Loop
//class pattern
//{
//    static void Main(string[] args)
//    {
//        int i = 0;
//        int j;
//        while (i <= 5)
//        {
//            j = 0;
//            while (j <= i)
//            {
//                Console.Write("*");
//                j++;
//            }
//            Console.WriteLine();
//            i++;
//        }

//    }
//}

//Do while Loop
//int num = 1;
//Console.WriteLine("Even Number");
//do
//{
//    if ((num % 2) == 0)
//    {
//        Console.WriteLine(num);
//    }
//    num = num + 1;
//} while (num <= 11);

//For Loop
int num;
Console.WriteLine("Even Number");
    for (num = 1; num<=11; num++)
{
    if ((num % 2) == 0)
    {
        Console.WriteLine(num);
    }
}

