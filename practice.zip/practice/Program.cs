﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using practice;

namespace Constructor_destructor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            color colors = new color();
            colors.Gradient();
            colors.Gradient();
            Student std = new Student();
            std.Student_table(111, "Ali", "000");
            std.Information();
            //Console.ReadKey();
        }
    }
}
