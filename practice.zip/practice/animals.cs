﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace practice
{
    internal class Red
    {
        public void Gradient()
        {
            Console.WriteLine("The color is red");
        }

    }
    internal class color : Red
    {
        public void Gradient()
        {
            Console.WriteLine("The color is white");
        }
    }
    internal class Student 

    {
        public int std_id;
        public string name;
        public string age;

        public void Student_table(int s_id,string s_name,string s_age)
        {
            std_id = s_id;
            name = s_name;
            age = s_age;
        }
        private void Student_Details()
        {
            Console.WriteLine("Enter Id is");
            int std_id=int.Parse(Console.ReadLine());
            Console.WriteLine("Your id is:"+std_id);

            Console.WriteLine("Enter your name");
            string name = Console.ReadLine();
            Console.WriteLine("Your name is:"+name);

            Console.WriteLine("Enter your age");
            string age = Console.ReadLine();
            Console.WriteLine("Your age is:" + age);
        }
        public void Information()
        {
            Student_Details();
            Console.WriteLine("E.g:" + std_id);
            Console.WriteLine("E.g:" + name);
            Console.WriteLine("E.g:" + age);
        }
        ~Student()
        {
            Console.WriteLine("Destruct");
        }
    }

}
