﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace arrays
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //integer array
            //int[] stdid = new int[5];
            //stdid[0] = 111;
            //stdid[1] = 222;
            //stdid[2] = 333;
            //stdid[3] = 444;

            //for ( int i = 0; i < 5; i++ ){
            //    Console.WriteLine("StudentId:" + stdid[i]);
            //}

            //string Array
            //string[] student = new string[2] { "Ali","Saad" };
            //for(int i = 0; i < student.Length; i++)
            //{
            //    Console.WriteLine(student[i]);
            //}

            //take input from user
            Console.WriteLine("Enter Array Length");
            //string[] stdname = new string[5];
            int count = int.Parse(Console.ReadLine());
            string[] stdname = new string[count];

            for (int i = 0; i < stdname.Length; i++)
            {
                Console.WriteLine("Enter Student Name:");
                stdname[i] = Console.ReadLine();
            }
            Console.WriteLine("------Name Of Students-------");
            for (int i = 0; i < stdname.Length; i++)
            {
                Console.WriteLine(i + ": " + stdname[i]);
            }
            Console.ReadKey();

        }
    }
}
