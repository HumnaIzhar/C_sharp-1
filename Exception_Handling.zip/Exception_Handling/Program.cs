﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_Handling
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter First Number");
            int num1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Second Number");
            int num2 = int.Parse(Console.ReadLine());

            // int result = num1/num2;
            int result = 0;
            try {
                result = num1 / num2;
            }
            catch (DivideByZeroException e){
                Console.WriteLine("can not divide any number by zero");
            }
            Console.WriteLine("The result is:"+result);


            //By array example
            try
            {
                int[] myarray = new int[5];
                myarray[0] = 111;
                myarray[1] = 222;
                myarray[2] = 333;
                myarray[3] = 444;
                myarray[4] = 555;
                //myarray[5] = 555;

                for (int i = 0; i < 5; i++)
                {
                    Console.Write(myarray[i]);
                }
            }
            catch(IndexOutOfRangeException i)
            {
                Console.WriteLine("Array index is out of range it can define only 5 values");
            }
            Console.ReadKey();
        }
    }
}
