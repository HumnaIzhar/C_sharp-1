﻿namespace CALCULATOR_APPLICATION
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Label1 = new Label();
            Label2 = new Label();
            Label3 = new Label();
            btn_add = new Button();
            btn_sub = new Button();
            btn_multi = new Button();
            btn_div = new Button();
            lbl_result = new Label();
            txt_num1 = new TextBox();
            txt_num2 = new TextBox();
            SuspendLayout();
            // 
            // Label1
            // 
            Label1.AutoSize = true;
            Label1.Font = new Font("Segoe UI", 20F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point);
            Label1.Location = new Point(200, 9);
            Label1.Name = "Label1";
            Label1.Size = new Size(371, 37);
            Label1.TabIndex = 1;
            Label1.Text = "CALCULATOR APPLICATION";
            // 
            // Label2
            // 
            Label2.AutoSize = true;
            Label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Label2.Location = new Point(178, 88);
            Label2.Name = "Label2";
            Label2.Size = new Size(192, 21);
            Label2.TabIndex = 2;
            Label2.Text = "Enter Your First Number";
            // 
            // Label3
            // 
            Label3.AutoSize = true;
            Label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Label3.Location = new Point(178, 136);
            Label3.Name = "Label3";
            Label3.Size = new Size(216, 21);
            Label3.TabIndex = 3;
            Label3.Text = "Enter Your Second Number";
            // 
            // btn_add
            // 
            btn_add.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btn_add.Location = new Point(178, 201);
            btn_add.Name = "btn_add";
            btn_add.Size = new Size(99, 34);
            btn_add.TabIndex = 5;
            btn_add.Text = "ADDITION";
            btn_add.UseVisualStyleBackColor = true;
            btn_add.Click += btn_add_Click;
            // 
            // btn_sub
            // 
            btn_sub.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btn_sub.Location = new Point(283, 201);
            btn_sub.Name = "btn_sub";
            btn_sub.Size = new Size(131, 34);
            btn_sub.TabIndex = 6;
            btn_sub.Text = "SUBTRACTION";
            btn_sub.UseVisualStyleBackColor = true;
            btn_sub.Click += btn_sub_Click;
            // 
            // btn_multi
            // 
            btn_multi.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btn_multi.Location = new Point(421, 201);
            btn_multi.Name = "btn_multi";
            btn_multi.Size = new Size(150, 34);
            btn_multi.TabIndex = 7;
            btn_multi.Text = "MULTIPLICATION";
            btn_multi.UseVisualStyleBackColor = true;
            btn_multi.Click += btn_multi_Click;
            // 
            // btn_div
            // 
            btn_div.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btn_div.Location = new Point(577, 201);
            btn_div.Name = "btn_div";
            btn_div.Size = new Size(92, 34);
            btn_div.TabIndex = 8;
            btn_div.Text = "DIVISION";
            btn_div.UseVisualStyleBackColor = true;
            btn_div.Click += btn_div_Click;
            // 
            // lbl_result
            // 
            lbl_result.AutoSize = true;
            lbl_result.Font = new Font("Segoe UI", 20F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_result.Location = new Point(178, 278);
            lbl_result.Name = "lbl_result";
            lbl_result.Size = new Size(119, 37);
            lbl_result.TabIndex = 9;
            lbl_result.Text = "RESULT:";
            // 
            // txt_num1
            // 
            txt_num1.Location = new Point(420, 78);
            txt_num1.Multiline = true;
            txt_num1.Name = "txt_num1";
            txt_num1.Size = new Size(249, 31);
            txt_num1.TabIndex = 10;
            // 
            // txt_num2
            // 
            txt_num2.Location = new Point(420, 124);
            txt_num2.Multiline = true;
            txt_num2.Name = "txt_num2";
            txt_num2.Size = new Size(249, 33);
            txt_num2.TabIndex = 11;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txt_num2);
            Controls.Add(txt_num1);
            Controls.Add(lbl_result);
            Controls.Add(btn_div);
            Controls.Add(btn_multi);
            Controls.Add(btn_sub);
            Controls.Add(btn_add);
            Controls.Add(Label3);
            Controls.Add(Label2);
            Controls.Add(Label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        internal Label Label1;
        internal Label Label2;
        internal Label Label3;
        internal Button btn_add;
        internal Button btn_sub;
        internal Button btn_multi;
        internal Button btn_div;
        internal Label lbl_result;
        internal TextBox txt_num1;
        internal TextBox txt_num2;
    }
}