namespace CALCULATOR_APPLICATION
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            int num_1 = int.Parse(txt_num1.Text);
            int num_2 = int.Parse(txt_num2.Text);
            int result = num_1 + num_2;
            lbl_result.Text = "Addition is :" + result;

        }

        private void btn_sub_Click(object sender, EventArgs e)
        {
            int num_1 = int.Parse(txt_num1.Text);
            int num_2 = int.Parse(txt_num2.Text);
            int result = num_1 - num_2;
            lbl_result.Text = "Subtraction is :" + result;
        }

        private void btn_multi_Click(object sender, EventArgs e)
        {
            int num_1 = int.Parse(txt_num1.Text);
            int num_2 = int.Parse(txt_num2.Text);
            int result = num_1 * num_2;
            lbl_result.Text = "Multiplication is :" + result;
        }

        private void btn_div_Click(object sender, EventArgs e)
        {
            int num_1 = int.Parse(txt_num1.Text);
            int num_2 = int.Parse(txt_num2.Text);
            int result = num_1 / num_2;
            lbl_result.Text = "Division is :" + result;
        }
    }
}