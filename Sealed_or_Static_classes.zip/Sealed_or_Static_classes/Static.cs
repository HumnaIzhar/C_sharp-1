﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Sealed_or_Static_classes
{
    static class Worker
    {
        public static void Print()
        {
            Console.WriteLine("This is static class with static method");
        }
    }
    sealed internal class Owner
        {
         public static void Print1() 
         {
            Console.WriteLine("Sealed class with static method");
         }
        }
} 
