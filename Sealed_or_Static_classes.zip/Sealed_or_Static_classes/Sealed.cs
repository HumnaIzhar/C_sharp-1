﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sealed_or_Static_classes;

namespace Sealed_or_Static_classes
{
    //Sealed class:Can make object and can inherit it. But dont inherit it as a base class.
    sealed internal class Employee:Student
    {
        public void show()
        {
            Console.WriteLine("this is sealed class");
        }
        public static void show1()
        {
            Console.WriteLine("this is a static sealed class member");
        }
    }
    
}
internal class Student
{
    public virtual void Show_message()
    {
        Console.WriteLine("This is inherited static class in sealed class");
    }
}
internal class Patient
{
    public virtual void Show_message2()
    {
        Console.WriteLine("This is inherited static class in sealed class");
    }
}


//Sealed class with sealed member
sealed internal class Customer:Patient
{
    sealed public override void Show_message2()
    {
        Console.WriteLine("This is sealed class with sealed method");

    }
}