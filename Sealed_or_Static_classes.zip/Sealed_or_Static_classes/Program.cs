﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sealed_or_Static_classes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Sealed class 
            Employee emp = new Employee();
            emp.show();
            Console.WriteLine("*******************");
            //Static method
            Employee.show1();
            Console.WriteLine("*******************");
            //Inherited static class in sealed class
            Student std = new Student();
            std.Show_message();
            Console.WriteLine("*******************");
            //Sealed class sealed method and inherited
            Customer cst = new Customer();
            cst.Show_message2();
            Console.WriteLine("*********************");
            //Employee.show_message();
            Console.WriteLine("********************");
            //Static class with static method
            Worker.Print();
            Console.WriteLine("*********************");
            //sealed class with static method
            Owner.Print1();

            Console.ReadKey();
        }
    }
}
