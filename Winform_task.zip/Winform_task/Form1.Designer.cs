﻿namespace Winform_task
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            fontDialog1 = new FontDialog();
            label1 = new Label();
            button3 = new Button();
            label2 = new Label();
            linkLabel1 = new LinkLabel();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ScrollBar;
            button1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = Color.DimGray;
            button1.Location = new Point(210, 126);
            button1.Name = "button1";
            button1.Size = new Size(415, 45);
            button1.TabIndex = 0;
            button1.Text = "Username";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ScrollBar;
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button2.ForeColor = Color.DimGray;
            button2.Location = new Point(210, 209);
            button2.Name = "button2";
            button2.Size = new Size(415, 40);
            button2.TabIndex = 1;
            button2.Text = "Password";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point);
            label1.ForeColor = Color.FloralWhite;
            label1.Location = new Point(337, 43);
            label1.Name = "label1";
            label1.Size = new Size(163, 32);
            label1.TabIndex = 2;
            label1.Text = "LOGIN FORM";
            label1.Click += label1_Click_1;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ScrollBar;
            button3.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            button3.ForeColor = Color.SeaGreen;
            button3.Location = new Point(355, 326);
            button3.Name = "button3";
            button3.Size = new Size(120, 40);
            button3.TabIndex = 3;
            button3.Text = "LOGIN";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.Silver;
            label2.Location = new Point(268, 87);
            label2.Name = "label2";
            label2.Size = new Size(304, 21);
            label2.TabIndex = 4;
            label2.Text = "Please enter your username and password";
            label2.Click += label2_Click;
            // 
            // linkLabel1
            // 
            linkLabel1.ActiveLinkColor = Color.DarkGoldenrod;
            linkLabel1.AutoSize = true;
            linkLabel1.Font = new Font("Segoe UI", 12F, FontStyle.Underline, GraphicsUnit.Point);
            linkLabel1.ForeColor = Color.LightSlateGray;
            linkLabel1.Location = new Point(337, 276);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(148, 21);
            linkLabel1.TabIndex = 5;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Forgotten Password";
            // 
            // Form1
            // 
            AccessibleRole = AccessibleRole.None;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.InfoText;
            ClientSize = new Size(800, 450);
            Controls.Add(linkLabel1);
            Controls.Add(label2);
            Controls.Add(button3);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(button1);
            Font = new Font("Segoe UI", 9F, FontStyle.Underline, GraphicsUnit.Point);
            HelpButton = true;
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private FontDialog fontDialog1;
        private Label label1;
        private Button button3;
        private Label label2;
        private LinkLabel linkLabel1;
    }
}