﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pillars_of_oops
{
    internal class Myclass
    {
        //non-parametric method
        public void add()
        {
            Console.WriteLine("Enter First Number");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Second number");
            int b = int.Parse(Console.ReadLine());

            Console.WriteLine("addition is:" + (a + b));
        }
        //parametric method
        public void show(string msg)
        {
            Console.WriteLine(msg);
        }
        //Polymorphism Examples:Same class but different parameters
        public void color(string name)
        {
            Console.WriteLine(name);

        }
        public void color(int quantity, string quality)
        {
            Console.WriteLine("This is quantity of color:" + quantity);
            Console.WriteLine("This is quality of color:" + quality);
        }

    }
    //Inhertance= parent class inherited to child class.
    internal class classA
    {
        public void showA()
        {
            Console.WriteLine("Enter Your Name");
            string a = Console.ReadLine();
            Console.WriteLine("Enter Your age");
            int b = int.Parse(Console.ReadLine());
            //Console.WriteLine("USERS INFORMATION");
            Console.WriteLine("Your name is:" + a);
            Console.WriteLine("Your name is:" + b);
        }

    }
    internal class classB : classA
    {
        public void showB()
        {
            Console.WriteLine("Enter Your country");
            string c = Console.ReadLine();
            Console.WriteLine("Enter Your city");
            string d = Console.ReadLine();

            Console.WriteLine("Your Country is:" + c);
            Console.WriteLine("Your city is:" + d);
        }
    }
    internal class classC : classB
    {
        public void showC()
        {
            Console.WriteLine("Enter Your Area");
            string e = Console.ReadLine();
            Console.WriteLine("Enter Your Language");
            string f = Console.ReadLine();


            Console.WriteLine("Your Area is:" + e);
            Console.WriteLine("Your Language is:" + f);
        }
    }
}
