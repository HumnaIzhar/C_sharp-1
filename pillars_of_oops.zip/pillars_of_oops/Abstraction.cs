﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pillars_of_oops
{   
//Abstraction:user put input and get output but dont concern with that how they get output.
    internal class Abstraction
    {
        public int emp_id;
        public string emp_name;
        public string emp_designation;
        public double net_salary;
        public double gross_salary;
        public double tax_deduction = 0.1;
         
        public void Employee(int eid,string ename,string edesig, double egrosssalary)
        {
            emp_id = eid;
            emp_name = ename;
            emp_designation = edesig;
            gross_salary = egrosssalary;
        }
        private void calculate_net_salary()
        {
            if(gross_salary >= 30000)
            {
                net_salary = gross_salary - (gross_salary * tax_deduction);
                Console.WriteLine("Your Net salary is:" + net_salary);
            }
            else
            {
                Console.WriteLine(gross_salary);
            }
        }
        public void calculate()
        {
            calculate_net_salary();
            Console.WriteLine(emp_id);
            Console.WriteLine(emp_name);
            Console.WriteLine(emp_designation);
            Console.WriteLine(gross_salary);
        }
    }
    
}
