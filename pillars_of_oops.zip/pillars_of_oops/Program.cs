﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pillars_of_oops
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //object
            Myclass myclass = new Myclass();
            //non-parametic object
            myclass.add();
            Console.WriteLine("*******************");
            //parametic object
            myclass.show("This is a message");
            Console.WriteLine("*******************");
            //Polymorphism object
            myclass.color("red");
            Console.WriteLine("*******************");
            myclass.color(8, "good");
            //inheritance
            Console.WriteLine("USERS INFORMATION");
            classC objc = new classC();
            objc.showA();
            objc.showB();
            objc.showC();
            //Abstraction
            Abstraction abstraction = new Abstraction();
            abstraction.Employee(111, "ali", "faculty", 55000);
            abstraction.calculate();
           
            Console.ReadKey();

        }
        
    }
}
