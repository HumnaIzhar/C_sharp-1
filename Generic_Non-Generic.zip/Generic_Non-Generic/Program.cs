﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic_Non_Generic
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Non_Generic
            //ArrayList
            ArrayList al = new ArrayList(3);
            al.Add(111);
            al.Add("Ali");
            al.Add("sara");
            al.Add(350);
            for(int i=0; i<al.Count; i++)
            {
                Console.WriteLine(al[i]);
            }
            //Console.WriteLine(al.Capacity);

            //Generic
            //Array
            int[] myclass = new int[3];
            myclass[0] = 111;
            myclass[1] = 222;
            myclass[2] = 333;

            for(int i=0;i<myclass.Length; i++)
            {
                Console.WriteLine(myclass[i]);
            }

            //List
            List<int> list = new List<int>();
            list.Add(10);
            list.Add(20);
            list.Add(30);
            list.Add(40);

            Console.WriteLine(list.Capacity);


            Console.ReadLine();
        }
    }
}    