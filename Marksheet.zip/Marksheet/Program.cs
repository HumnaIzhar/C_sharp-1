﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using System.Numerics;

Console.WriteLine("Enter Your Name");
string std_name = Console.ReadLine();
Console.WriteLine("Student Name is :" + std_name);

Console.WriteLine("Enter Your Student_id");
int std_id = int.Parse(Console.ReadLine());
Console.WriteLine("Student_Id is :" + std_id);

Console.WriteLine("Enter Your Course");
string std_course = Console.ReadLine();
Console.WriteLine("Student Course is :" + std_course);

Console.WriteLine("Enter Your Semster");
int std_sems= int.Parse(Console.ReadLine());
Console.WriteLine("Student Semster is :" + std_sems);

Console.WriteLine("Enter Your Html Marks");
int html = int.Parse(Console.ReadLine());
Console.WriteLine("Student Html marks is :" + html);

Console.WriteLine("Enter Your php marks");
int php = int.Parse(Console.ReadLine());
Console.WriteLine("Student php Marks is :" + php);

Console.WriteLine("Enter Your C-sharp Marks");
int c_sharp = int.Parse(Console.ReadLine());
Console.WriteLine("Student C_sharp Marks is :" + c_sharp);

int total = 300;
Console.WriteLine("Your total Marks is:" + total);

int obt = html + php + c_sharp;
Console.WriteLine("Your Obtained Marks is:" + obt);

//double per = obt / total;
//Console.WriteLine("Your Percentage is:" + per * 100);
int per = (int)Math.Round((double)(100 * obt) / total);
Console.WriteLine("Your Percentage is:" + per );


